
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact" style="margin-top: 50px;">
      <div class="container">

        <div class="section-title">
          <h2>SLSU-TO MAP</h2>
        </div>
      </div>

      <div class="container">
        <div class="row">

          <div class="col-lg-12">
            <iframe src="<?php echo base_url(); ?>assets/map/index.html" style="width: 100%; height: 400px;border: 1px solid gray"></iframe>

          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->
