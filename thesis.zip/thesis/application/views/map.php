<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>GIS Based SLSU-TO Students Information System</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="initial-scale=1,user-scalable=no,maximum-scale=1,width=device-width">
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/map/css/leaflet.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/map/css/L.Control.Locate.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/map/css/qgis2web.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/map/css/fontawesome-all.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/map/css/leaflet-search.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/map/routing/dist/leaflet-routing-machine.css" />
	<style>
	html, body, #map {
	    width: 100%;
	    height: 100%;
	    padding: 0;
	    margin: 0;
	}
	#map
	{
		height: 100%;
		background-color: #bde9ff;
	}
	.leaflet-top{
		top: 90px;
	}
	footer{
		position: fixed;
		bottom: 0px;
		width: 100%;
		height: 30px;
	}
	</style>
  <!-- Favicons -->
  <link href="<?php echo base_url(); ?>assets/img/logo.png" rel="icon">
  <link href="<?php echo base_url(); ?>assets/img/logo.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo base_url(); ?>assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Medilab - v4.9.1
  * Template URL: https://bootstrapmade.com/medilab-free-medical-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <!-- <div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope"></i> <a href="mailto:contact@example.com">contact@example.com</a>
        <i class="bi bi-phone"></i> +1 5589 55488 55
      </div>
      <div class="d-none d-lg-flex social-links align-items-center">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
      </div>
    </div>
  </div> -->

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <!-- <h1 class="logo me-auto"><a href="index.html">Medilab</a></h1> -->
      <!-- Uncomment below if you prefer to use an image logo -->
       <a href="index.html" class="logo me-auto"><img src="<?php echo base_url(); ?>assets/img/logo.png" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a href="<?php echo base_url(); ?>" class="nav-link <?php echo $this->nativesession->get('activelink1'); ?>">Home</a></li>
          <li><a href="<?php echo base_url(); ?>index.php/users/map" class="nav-link <?php echo $this->nativesession->get('activelink2'); ?>">Map</a></li>
          <li class="dropdown"><a href="#" class="nav-link <?php echo $this->nativesession->get('activelink3'); ?>"><span>Offices</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="#">Drop Down 1</a></li>
              <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="#">Drop Down 2</a></li>
              <li><a href="#">Drop Down 3</a></li>
              <li><a href="#">Drop Down 4</a></li>
            </ul>
          </li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
      <form>
        <input type="text" name="" class="searchbox" placeholder="Search Building...">
        <button class="searchbtn"><i class="bx bx-search"></i></button>
      </form>
    </div>
  </header><!-- End Header -->
	<div id="map"></div>
        <script src="<?php echo base_url(); ?>assets/map/js/qgis2web_expressions.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/js/leaflet.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/js/L.Control.Locate.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/js/multi-style-layer.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/js/leaflet.rotatedMarker.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/js/leaflet.pattern.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/js/leaflet-hash.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/js/Autolinker.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/js/rbush.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/js/labelgun.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/js/labels.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/js/leaflet-search.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/data/Bay_0.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/data/relativebarangay_1.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/data/OSMCut_2.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/data/SLSU_Border_3.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/data/Roads_4.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/data/MaasinMacrohonSogodRoad_5.js"></script>
        <script src="<?php echo base_url(); ?>assets/map/data/Buildings_6.js"></script>
        <script>
        var map = L.map('map', {
            zoomControl:true, maxZoom:18, minZoom:16
        })
        var hash = new L.Hash(map);
        map.attributionControl.setPrefix('<a href="https://github.com/tomchadwin/qgis2web" target="_blank">qgis2web</a> &middot; <a href="https://leafletjs.com" title="A JS library for interactive maps">Leaflet</a> &middot; <a href="https://qgis.org">QGIS</a>');
        var autolinker = new Autolinker({truncate: {length: 30, location: 'smart'}});
        L.control.locate({locateOptions: {maxZoom: 18}}).addTo(map);
        var bounds_group = new L.featureGroup([]);
        function setBounds() {
            if (bounds_group.getLayers().length) {
                map.fitBounds(bounds_group.getBounds());
            }
        }
        function pop_Bay_0(feature, layer) {
            var popupContent = '<table>\
                    <tr>\
                        <th>' + (feature.properties['name'] !== null ? autolinker.link(feature.properties['name'].toLocaleString()) : '') + '</th>\
                    </tr>\
                </table>';
            layer.bindPopup(popupContent, {maxHeight: 400});
        }

        function style_Bay_0_0() {
            return {
                pane: 'pane_Bay_0',
                opacity: 1,
                color: 'rgba(175,179,138,1.0)',
                dashArray: '',
                lineCap: 'butt',
                lineJoin: 'miter',
                weight: 1.0, 
                fill: true,
                fillOpacity: 1,
                fillColor: 'rgba(179,211,253,1.0)',
                interactive: true,
            }
        }
        function style_Bay_0_1() {
            return {
                pane: 'pane_Bay_0',
                interactive: true,
            }
        }
        map.createPane('pane_Bay_0');
        map.getPane('pane_Bay_0').style.zIndex = 400;
        map.getPane('pane_Bay_0').style['mix-blend-mode'] = 'normal';
        var layer_Bay_0 = new L.geoJson.multiStyle(json_Bay_0, {
            attribution: '',
            interactive: true,
            dataVar: 'json_Bay_0',
            layerName: 'layer_Bay_0',
            pane: 'pane_Bay_0',
            onEachFeature: pop_Bay_0,
            styles: [style_Bay_0_0,style_Bay_0_1,]
        });
        bounds_group.addLayer(layer_Bay_0);
        map.addLayer(layer_Bay_0);
        function pop_relativebarangay_1(feature, layer) {
            var popupContent = '<table>\
                    <tr>\
                        <td><b>' + (feature.properties['barangay'] !== null ? autolinker.link(feature.properties['barangay'].toLocaleString()) : '') + '</b></td>\
                    </tr>\
                    <tr>\
                        <td colspan="2"><b>' + (feature.properties['municipali'] !== null ? autolinker.link(feature.properties['municipali'].toLocaleString()) : '') + '</b></td>\
                    </tr>\
                    <tr>\
                        <td colspan="2"><b>' + (feature.properties['province'] !== null ? autolinker.link(feature.properties['province'].toLocaleString()) : '') + '</b></td>\
                    </tr>\
                </table>';
            layer.bindPopup(popupContent, {maxHeight: 400});
        }

        function style_relativebarangay_1_0() {
            return {
                pane: 'pane_relativebarangay_1',
                opacity: 1,
                color: 'rgba(114,133,132,1.0)',
                dashArray: '',
                lineCap: 'butt',
                lineJoin: 'miter',
                weight: 1.0, 
                fill: true,
                fillOpacity: 1,
                fillColor: 'rgba(255,213,151,1.0)',
                interactive: true,
            }
        }
        var pattern_relativebarangay_1_1 = new L.StripePattern({
            weight: 0.26,
            spaceWeight: 2.0,
            color: '#000000',
            opacity: 1.0,
            spaceOpacity: 0,
            angle: 315
        });
        pattern_relativebarangay_1_1.addTo(map);
        function style_relativebarangay_1_1() {
            return {
                pane: 'pane_relativebarangay_1',
                stroke: false,
                fillOpacity: 1,
                fillPattern: pattern_relativebarangay_1_1,
                interactive: true,
            }
        }
        map.createPane('pane_relativebarangay_1');
        map.getPane('pane_relativebarangay_1').style.zIndex = 401;
        map.getPane('pane_relativebarangay_1').style['mix-blend-mode'] = 'normal';
        var layer_relativebarangay_1 = new L.geoJson.multiStyle(json_relativebarangay_1, {
            attribution: '',
            interactive: true,
            dataVar: 'json_relativebarangay_1',
            layerName: 'layer_relativebarangay_1',
            pane: 'pane_relativebarangay_1',
            onEachFeature: pop_relativebarangay_1,
            styles: [style_relativebarangay_1_0,style_relativebarangay_1_1,]
        });
        bounds_group.addLayer(layer_relativebarangay_1);
        map.addLayer(layer_relativebarangay_1);
        function pop_OSMCut_2(feature, layer) {
            var popupContent = '<table>\
                    <tr>\
                        <td colspan="2">' + (feature.properties['id'] !== null ? autolinker.link(feature.properties['id'].toLocaleString()) : '') + '</td>\
                    </tr>\
                </table>';
            layer.bindPopup(popupContent, {maxHeight: 400});
        }

        function style_OSMCut_2_0() {
            return {
                pane: 'pane_OSMCut_2',
                opacity: 1,
                color: 'rgba(35,35,35,1.0)',
                dashArray: '',
                lineCap: 'butt',
                lineJoin: 'miter',
                weight: 1.0, 
                fill: true,
                fillOpacity: 1,
                fillColor: 'rgba(243,166,178,1.0)',
                interactive: true,
            }
        }
        map.createPane('pane_OSMCut_2');
        map.getPane('pane_OSMCut_2').style.zIndex = 402;
        map.getPane('pane_OSMCut_2').style['mix-blend-mode'] = 'normal';
        var layer_OSMCut_2 = new L.geoJson(json_OSMCut_2, {
            attribution: '',
            interactive: true,
            dataVar: 'json_OSMCut_2',
            layerName: 'layer_OSMCut_2',
            pane: 'pane_OSMCut_2',
            onEachFeature: pop_OSMCut_2,
            style: style_OSMCut_2_0,
        });
        bounds_group.addLayer(layer_OSMCut_2);
        map.addLayer(layer_OSMCut_2);
        function pop_SLSU_Border_3(feature, layer) {
            var popupContent = '<table>\
                    <tr>\
                        <td colspan="2">' + (feature.properties['name'] !== null ? autolinker.link(feature.properties['name'].toLocaleString()) : '') + '</td>\
                    </tr>\
                </table>';
            layer.bindPopup(popupContent, {maxHeight: 400});
        }

        function style_SLSU_Border_3_0() {
            return {
                pane: 'pane_SLSU_Border_3',
                opacity: 1,
                color: 'rgba(114,133,132,1.0)',
                dashArray: '',
                lineCap: 'butt',
                lineJoin: 'miter',
                weight: 1.0, 
                fill: true,
                fillOpacity: 1,
                fillColor: 'rgba(117,255,145,1.0)',
                interactive: true,
            }
        }
        var pattern_SLSU_Border_3_1 = new L.StripePattern({
            weight: 0.26,
            spaceWeight: 2.0,
            color: '#000000',
            opacity: 1.0,
            spaceOpacity: 0,
            angle: 315
        });
        pattern_SLSU_Border_3_1.addTo(map);
        function style_SLSU_Border_3_1() {
            return {
                pane: 'pane_SLSU_Border_3',
                stroke: false,
                fillOpacity: 1,
                fillPattern: pattern_SLSU_Border_3_1,
                interactive: true,
            }
        }
        map.createPane('pane_SLSU_Border_3');
        map.getPane('pane_SLSU_Border_3').style.zIndex = 403;
        map.getPane('pane_SLSU_Border_3').style['mix-blend-mode'] = 'normal';
        var layer_SLSU_Border_3 = new L.geoJson.multiStyle(json_SLSU_Border_3, {
            attribution: '',
            interactive: true,
            dataVar: 'json_SLSU_Border_3',
            layerName: 'layer_SLSU_Border_3',
            pane: 'pane_SLSU_Border_3',
            onEachFeature: pop_SLSU_Border_3,
            styles: [style_SLSU_Border_3_0,style_SLSU_Border_3_1,]
        });
        bounds_group.addLayer(layer_SLSU_Border_3);
        map.addLayer(layer_SLSU_Border_3);
        function pop_Roads_4(feature, layer) {
            var popupContent = '<table>\
                    <tr>\
                        <th scope="row">road</th>\
                        <td>' + (feature.properties['road'] !== null ? autolinker.link(feature.properties['road'].toLocaleString()) : '') + '</td>\
                    </tr>\
                </table>';
            layer.bindPopup(popupContent, {maxHeight: 400});
        }

        function style_Roads_4_0() {
            return {
                pane: 'pane_Roads_4',
                opacity: 1,
                color: 'rgba(255,255,255,1.0)',
                dashArray: '',
                lineCap: 'round',
                lineJoin: 'round',
                weight: 9.0,
                fillOpacity: 0,
                interactive: true,
            }
        }
        function style_Roads_4_1() {
            return {
                pane: 'pane_Roads_4',
                opacity: 1,
                color: 'rgba(249,246,53,1.0)',
                dashArray: '',
                lineCap: 'round',
                lineJoin: 'round',
                weight: 5.0,
                fillOpacity: 0,
                interactive: true,
            }
        }
        map.createPane('pane_Roads_4');
        map.getPane('pane_Roads_4').style.zIndex = 404;
        map.getPane('pane_Roads_4').style['mix-blend-mode'] = 'normal';
        var layer_Roads_4 = new L.geoJson.multiStyle(json_Roads_4, {
            attribution: '',
            interactive: true,
            dataVar: 'json_Roads_4',
            layerName: 'layer_Roads_4',
            pane: 'pane_Roads_4',
            onEachFeature: pop_Roads_4,
            styles: [style_Roads_4_0,style_Roads_4_1,]
        });
        bounds_group.addLayer(layer_Roads_4);
        map.addLayer(layer_Roads_4);
        function pop_MaasinMacrohonSogodRoad_5(feature, layer) {
            var popupContent = '<table>\
                    <tr>\
                        <th scope="row">name</th>\
                        <td>' + (feature.properties['name'] !== null ? autolinker.link(feature.properties['name'].toLocaleString()) : '') + '</td>\
                    </tr>\
                </table>';
            layer.bindPopup(popupContent, {maxHeight: 400});
        }

        function style_MaasinMacrohonSogodRoad_5_0() {
            return {
                pane: 'pane_MaasinMacrohonSogodRoad_5',
                opacity: 1,
                color: 'rgba(20,50,50,1.0)',
                dashArray: '',
                lineCap: 'round',
                lineJoin: 'round',
                weight: 15.0,
                fillOpacity: 0,
                interactive: true,
            }
        }
        function style_MaasinMacrohonSogodRoad_5_1() {
            return {
                pane: 'pane_MaasinMacrohonSogodRoad_5',
                opacity: 1,
                color: 'rgba(94,146,148,1.0)',
                dashArray: '',
                lineCap: 'round',
                lineJoin: 'round',
                weight: 14.0,
                fillOpacity: 0,
                interactive: true,
            }
        }
        map.createPane('pane_MaasinMacrohonSogodRoad_5');
        map.getPane('pane_MaasinMacrohonSogodRoad_5').style.zIndex = 405;
        map.getPane('pane_MaasinMacrohonSogodRoad_5').style['mix-blend-mode'] = 'normal';
        var layer_MaasinMacrohonSogodRoad_5 = new L.geoJson.multiStyle(json_MaasinMacrohonSogodRoad_5, {
            attribution: '',
            interactive: true,
            dataVar: 'json_MaasinMacrohonSogodRoad_5',
            layerName: 'layer_MaasinMacrohonSogodRoad_5',
            pane: 'pane_MaasinMacrohonSogodRoad_5',
            onEachFeature: pop_MaasinMacrohonSogodRoad_5,
            styles: [style_MaasinMacrohonSogodRoad_5_0,style_MaasinMacrohonSogodRoad_5_1,]
        });
        bounds_group.addLayer(layer_MaasinMacrohonSogodRoad_5);
        map.addLayer(layer_MaasinMacrohonSogodRoad_5);
        function pop_Buildings_6(feature, layer) {
            var popupContent = '<table>\
                    <tr>\
                        <th>' + (feature.properties['building'] !== null ? autolinker.link(feature.properties['building'].toLocaleString()) : '') + '</th>\
                    </tr>\
                    <tr>\
                        <td><img src="<?php echo base_url(); ?>assets/map/buildings/' + (feature.properties['image'] !== null ? autolinker.link(feature.properties['image'].toLocaleString()) : '') + '.jpg" style="width:200px;"></td>\
                    </tr>\
                </table>';
            layer.bindPopup(popupContent, {maxHeight: 400});
        }

        function style_Buildings_6_0() {
            return {
                pane: 'pane_Buildings_6',
                opacity: 1,
                color: 'rgba(82,82,82,1.0)',
                dashArray: '',
                lineCap: 'butt',
                lineJoin: 'miter',
                weight: 1.0, 
                fill: true,
                fillOpacity: 1,
                fillColor: 'rgba(247,247,247,1.0)',
                interactive: true,
            }
        }
        map.createPane('pane_Buildings_6');
        map.getPane('pane_Buildings_6').style.zIndex = 406;
        map.getPane('pane_Buildings_6').style['mix-blend-mode'] = 'normal';
        var layer_Buildings_6 = new L.geoJson(json_Buildings_6, {
            attribution: '',
            interactive: true,
            dataVar: 'json_Buildings_6',
            layerName: 'layer_Buildings_6',
            pane: 'pane_Buildings_6',
            onEachFeature: pop_Buildings_6,
            style: style_Buildings_6_0,
        });
        bounds_group.addLayer(layer_Buildings_6);
        map.addLayer(layer_Buildings_6);L.control.scale({position: 'bottomleft', maxWidth: 100, metric: true, imperial: false, updateWhenIdle: false}).addTo(map);
        setBounds();
        var i = 0;
        layer_Bay_0.eachLayer(function(layer) {
            var context = {
                feature: layer.feature,
                variables: {}
            };
            layer.bindTooltip((layer.feature.properties['name'] !== null?String('<div style="color: #323232; font-size: 10pt; font-family: \'Arial\', sans-serif;">' + layer.feature.properties['name']) + '</div>':''), {permanent: true, offset: [-0, -16], className: 'css_Bay_0'});
            labels.push(layer);
            totalMarkers += 1;
              layer.added = true;
              addLabel(layer, i);
              i++;
        });
        var i = 0;
        layer_relativebarangay_1.eachLayer(function(layer) {
            var context = {
                feature: layer.feature,
                variables: {}
            };
            layer.bindTooltip((exp_label_relativebarangay_1_eval_expression(context) !== null?String('<div style="color: #323232; font-size: 10pt; font-family: \'Arial\', sans-serif;">' + exp_label_relativebarangay_1_eval_expression(context)) + '</div>':''), {permanent: true, offset: [-0, -16], className: 'css_relativebarangay_1'});
            labels.push(layer);
            totalMarkers += 1;
              layer.added = true;
              addLabel(layer, i);
              i++;
        });
        var i = 0;
        layer_SLSU_Border_3.eachLayer(function(layer) {
            var context = {
                feature: layer.feature,
                variables: {}
            };
            layer.bindTooltip((layer.feature.properties['name'] !== null?String('<div style="color: #323232; font-size: 14pt; font-weight: bold; font-family: \'Arial Black\', sans-serif;">' + layer.feature.properties['name']) + '</div>':''), {permanent: true, offset: [-0, -16], className: 'css_SLSU_Border_3'});
            labels.push(layer);
            totalMarkers += 1;
              layer.added = true;
              addLabel(layer, i);
              i++;
        });
        var i = 0;
        layer_Roads_4.eachLayer(function(layer) {
            var context = {
                feature: layer.feature,
                variables: {}
            };
            layer.bindTooltip((layer.feature.properties['road'] !== null?String('<div style="color: #323232; font-size: 10pt; font-family: \'Arial\', sans-serif;">' + layer.feature.properties['road']) + '</div>':''), {permanent: true, offset: [-0, -16], className: 'css_Roads_4'});
            labels.push(layer);
            totalMarkers += 1;
              layer.added = true;
              addLabel(layer, i);
              i++;
        });
        var i = 0;
        layer_MaasinMacrohonSogodRoad_5.eachLayer(function(layer) {
            var context = {
                feature: layer.feature,
                variables: {}
            };
            layer.bindTooltip((layer.feature.properties['name'] !== null?String('<div style="color: #323232; font-size: 10pt; font-family: \'Arial\', sans-serif;">' + layer.feature.properties['name']) + '</div>':''), {permanent: true, offset: [-0, -16], className: 'css_MaasinMacrohonSogodRoad_5'});
            labels.push(layer);
            totalMarkers += 1;
              layer.added = true;
              addLabel(layer, i);
              i++;
        });
        var i = 0;
        layer_Buildings_6.eachLayer(function(layer) {
            var context = {
                feature: layer.feature,
                variables: {}
            };
            layer.bindTooltip((layer.feature.properties['building'] !== null?String('<div style="color: #323232; font-size: 10pt; font-family: \'Arial\', sans-serif;">' + layer.feature.properties['building']) + '</div>':''), {permanent: true, offset: [-0, -16], className: 'css_Buildings_6'});
            labels.push(layer);
            totalMarkers += 1;
              layer.added = true;
              addLabel(layer, i);
              i++;
        });
        map.addControl(new L.Control.Search({
            layer: layer_Buildings_6,
            initial: false,
            hideMarkerOnCollapse: true,
            propertyName: 'building'}));
        document.getElementsByClassName('search-button')[0].className +=
         ' fa fa-binoculars';
        resetLabels([layer_Bay_0,layer_relativebarangay_1,layer_SLSU_Border_3,layer_Roads_4,layer_MaasinMacrohonSogodRoad_5,layer_Buildings_6]);
        map.on("zoomend", function(){
            resetLabels([layer_Bay_0,layer_relativebarangay_1,layer_SLSU_Border_3,layer_Roads_4,layer_MaasinMacrohonSogodRoad_5,layer_Buildings_6]);
        });
        map.on("layeradd", function(){
            resetLabels([layer_Bay_0,layer_relativebarangay_1,layer_SLSU_Border_3,layer_Roads_4,layer_MaasinMacrohonSogodRoad_5,layer_Buildings_6]);
        });
        map.on("layerremove", function(){
            resetLabels([layer_Bay_0,layer_relativebarangay_1,layer_SLSU_Border_3,layer_Roads_4,layer_MaasinMacrohonSogodRoad_5,layer_Buildings_6]);
        });
        </script>
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="container d-md-flex">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; GIS Based SLSU-TO Students Information System
        </div>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url(); ?>assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url(); ?>assets/js/main.js"></script>

</body>

</html>