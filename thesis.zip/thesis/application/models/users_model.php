<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class users_model extends CI_Model {

	
	
	public function insert($table,$data)
	{
		$this->db->insert($table,$data);
	}
	public function update($table,$data,$col,$id)
	{
		$this->db->where($col,$id);
		$this->db->update($table,$data);
	}
	public function getTable($table)
	{
		$this->db->from($table);
		return $this->db->get()->result();
	}
	public function getRow($table,$row,$data)
	{
		$this->db->from($table);
		$this->db->where($row,$data);
		return $this->db->get()->row();
	}
}

?>