<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class users extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->model("users_model");
		date_default_timezone_set("Asia/Manila");
	}
	public function index()
	{
		$data['buildings'] = $this->users_model->getTable('buildings');
		$this->nativesession->set('activelink1','active');
		$this->nativesession->set('activelink2','');
		$this->nativesession->set('activelink3','');
		$this->load->view('head');
		$this->load->view('index',$data);
		$this->load->view('footer');
	}
	public function search()
	{
		$data['buildings'] = $this->users_model->getTable('buildings');
		$location = $this->input->post('location');
		$destination = $this->input->post('destination');
		$this->nativesession->set('activelink1','');
		$this->nativesession->set('activelink2','active');
		$this->nativesession->set('activelink3','');
		$this->load->view('head');
		$this->load->view('search',$data);
		$this->load->view('footer');
	}
	public function map()
	{
		$data['buildings'] = $this->users_model->getTable('buildings');
		$location = $this->input->post('location');
		$destination = $this->input->post('destination');
		$this->nativesession->set('activelink1','');
		$this->nativesession->set('activelink2','active');
		$this->nativesession->set('activelink3','');
		$this->load->view('map',$data);
	}
	public function map2()
	{
		$this->load->view('map2');
	}
}
